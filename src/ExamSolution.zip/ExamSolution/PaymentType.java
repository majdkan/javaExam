package ExamSolution


public enum PaymentType {
    CREDIT_CARD, CASH, CHECK, OTHER
}
