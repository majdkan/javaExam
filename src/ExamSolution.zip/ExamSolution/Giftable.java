package ExamSolution;
public interface Giftable {

        void openGift();
    }


