package ExamSolution;


    public  abstract class BasketballGift implements Giftable{
        {
        @Override{
        public void openGift() {
            System.out.println("Congratulations! you got a new gift! Enjoy!");
        }
    }

}
