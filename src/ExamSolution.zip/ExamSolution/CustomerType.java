package ExamSolution;

public enum CustomerType {

        REGULAR, VIP
    }


