package ExamSolution;

import java.time.LocalDateTime;
import java.util.ArrayList;

    public class Main {
        public static void main(String[] args) throws Exception {
            Item desk = new Item(1, "Desk", 100D);
            Item football = new Item(2, "Football", 50D);
            Item computer = new Item(3, "computer", 500D);

            ArrayList<Item> firstCustomerFavoriteItems = new ArrayList<Item>();
            ArrayList<Item> secondCustomerFavoriteItems = new ArrayList<Item>();
            Customer firstCustomer = new Customer(1, "Noam", "Yaakov", "noam@gmail.com", "Holon", CustomerType.VIP, 100D, firstCustomerFavoriteItems);
            Customer secondCustomer = new Customer(1, "Alon", "Sofer", "alon@gmail.com", "Bat Yam", CustomerType.VIP, 50D, secondCustomerFavoriteItems);


            ArrayList<Item> firstVipOrderItemList = new ArrayList<Item>();
            firstVipOrderItemList.add(desk);
            firstVipOrderItemList.add(computer);

            VipOrder firstVipOrder = new VipOrder(1, "Noam Order", "Holon", firstVipOrderItemList, firstCustomer, PaymentType.CREDIT_CARD, LocalDateTime.now());
            System.out.println(firstVipOrder.getTotalPrice());
            for(Item favoriteItem : firstCustomer.getFavoriteItems()){
                System.out.println(favoriteItem.getName());
            }
//        500 + 100 -100 = 500D


        }
    }
}
