package ExamSolution;

 public interface Priceable {
    Double calculateTotalPrice() throws Exception;
}


